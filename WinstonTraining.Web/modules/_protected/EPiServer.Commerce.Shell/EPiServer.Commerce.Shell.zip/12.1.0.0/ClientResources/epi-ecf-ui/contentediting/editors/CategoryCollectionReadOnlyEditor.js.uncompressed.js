﻿define("epi-ecf-ui/contentediting/editors/CategoryCollectionReadOnlyEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/topic",

    // dijit
    "dijit/form/Button",

    // epi commerce
    "./CategoryCollectionEditor",
    "../viewmodel/CategoryCollectionReadOnlyEditorModel",
    "./_LanguageRestrictedEditButtonMixin",

    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.categorycollectioneditor"
],
    function (
        //dojo
        declare,
        topic,

        // dijit
        Button,

        // epi commerce
        CategoryCollectionEditor,
        CategoryCollectionReadOnlyEditorModel,
        _LanguageRestrictedEditButtonMixin,

        // Resources
        resources
    ) {
        return declare([CategoryCollectionEditor, _LanguageRestrictedEditButtonMixin], {
            // module: 
            //      epi-ecf-ui/contentediting/editors/RelationCollectionEditor
            // summary:
            //      Represents the Read-only editor widget for product's inventory list.

            _gridCollectionSettings: { readOnly: true },

            iconClass: "epi-iconCategory",

            modelType: CategoryCollectionReadOnlyEditorModel,

            changeToView: "linksview",

            buttonLabel: resources.editbuttontext,

            _renderNoDataMessage: function () {
                this.inherited(arguments);

                this.grid.set("noDataMessage", resources.nodatamessage);
            },

            postCreate: function () {
                this.inherited(arguments);

                this.set("title", "");
            }
        });
    });