﻿define("epi-ecf-ui/contentediting/viewmodel/PriceCollectionReadOnlyEditorModel", [
    // dojo
    "dojo/_base/declare",
    "dojo/currency",
    // dojox
    "dojox/html/entities",

    "epi/datetime",

    "./ReadOnlyCollectionEditorModel",

    // Resources
    "epi/i18n!epi/cms/nls/commerce.widget.pricecollection.message"
],
function (
    //dojo
    declare,
    currency,
    // dojox
    htmlEntities,

    epiDate,

    ReadOnlyCollectionEditorModel,

    // Resources
    res
) {
    return declare([ReadOnlyCollectionEditorModel], {
        // module:
        //      epi-ecf-ui/contentediting/viewmodel/PriceCollectionReadOnlyEditorModel
        // summary:
        //      Represents the model for PriceCollectionReadOnlyEditor

        _storeKey: "epi.commerce.price",

        res: res,

        generateFormatters: function (columnDefinitions) {
            // summary:
            //      Generate formatters for the specified column definitions.
            // columnDefinitions:
            //      The definition for the columns that should get the generated formatters.
            // tags:
            //      override

            this.inherited(arguments);
            columnDefinitions.validDate.formatter = this._formatValidDate.bind(this);
            columnDefinitions.unitPrice.formatter = function(value) {
                return currency.format(value.amount, { currency: value.currency });
            };
            columnDefinitions.priceCode.formatter = function (value) {
                return htmlEntities.encode(value);
            };
            return columnDefinitions;
        },

        _formatValidDate: function (value) {
            // Format datetime
            return this._formatDate(value.validFrom) + " - " + this._formatDate(value.validUntil);
        },

        _formatDate: function (datetime) {
            // summary:
            //      Format datetime to short type.
            // datetime: Object
            //      The raw data.
            // tags:
            //      public

            return datetime && datetime !== "" ? epiDate.toUserFriendlyString(datetime) : this.res.untildatenotdefined;
        },

        createQuery: function (referenceId) {
            return { referenceId: referenceId, query: "readonlyprices" };
        }
    });
});